# Kidney Stone Fiber > 2024-11-06 10:53am
https://universe.roboflow.com/ilk-awfpp/kidney-stone-fiber-chmjv

Provided by a Roboflow user
License: CC BY 4.0

