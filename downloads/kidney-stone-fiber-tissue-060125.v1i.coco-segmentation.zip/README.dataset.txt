# kidney-stone-fiber-tissue-060125 > 2025-01-06 10:11am
https://universe.roboflow.com/ilk-awfpp/kidney-stone-fiber-tissue-060125

Provided by a Roboflow user
License: CC BY 4.0

